import asyncio
import random
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder

# Token and Configuration
TOKEN = "YOUR_TELEGRAM_BOT_TOKEN_HERE"  # Replace with your actual bot token

logging.basicConfig(level=logging.INFO)
bot = Bot(token=TOKEN)
dp = Dispatcher()

# Complete Quotex OTC Pairs from your screenshots
OTC_PAIRS = [
    "USD/IDR (OTC)", "USD/BRL (OTC)", "USD/JPY (OTC)", "AUD/NZD (OTC)", 
    "EUR/JPY (OTC)", "NZD/JPY (OTC)", "AUD/JPY (OTC)", "AUD/USD (OTC)", 
    "GBP/NZD (OTC)", "NZD/CAD (OTC)", "CAD/CHF (OTC)", "EUR/USD (OTC)", 
    "CAD/JPY (OTC)", "EUR/GBP (OTC)", "USD/BDT (OTC)", "AUD/CHF (OTC)", 
    "USD/EGP (OTC)", "USD/COP (OTC)", "USD/PHP (OTC)", "GBP/USD (OTC)", 
    "USD/DZD (OTC)", "USD/PKR (OTC)", "AUD/CAD (OTC)", "NZD/USD (OTC)", 
    "USD/INR (OTC)", "USD/NGN (OTC)", "EUR/AUD (OTC)", "NZD/CHF (OTC)", 
    "USD/CAD (OTC)", "EUR/CAD (OTC)", "GBP/CAD (OTC)", "USD/ARS (OTC)", 
    "GBP/AUD (OTC)", "CHF/JPY (OTC)", "EUR/CHF (OTC)", "USD/CHF (OTC)", 
    "GBP/JPY (OTC)", "EUR/NZD (OTC)", "GBP/CHF (OTC)", "USD/ZAR (OTC)"
]

TIMEFRAMES = ["3s", "5s", "10s", "15s"]

@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    builder = InlineKeyboardBuilder()
    for tf in TIMEFRAMES:
        builder.button(text=f"🎯 {tf} VIP Signal", callback_data=f"signal_{tf}")
    builder.adjust(2)
    
    welcome_text = (
        "💎 *WELCOME TO TRADER EHAAN SIGNAL* 💎\n\n"
        "✨ *Brand:* Prince Ehaan\n"
        "👑 *Trader:* Ꭾʀɪ፝֟፝ɴꮯᴇ Ꭼнꫝن 🩷🌸\n"
        "🔗 *Telegram:* @PrinceEhaan\n\n"
        "👇 *Select your preferred time frame below to get lightning-fast VIP OTC signals:*"
    )
    
    await message.answer(welcome_text, parse_mode="Markdown", reply_markup=builder.as_markup())

@dp.callback_query(lambda c: c.data.startswith("signal_"))
async def send_trade_signal(callback: types.CallbackQuery):
    tf = callback.data.split("_")[1]
    pair = random.choice(OTC_PAIRS)
    signal_type = random.choice(["🟢 CALL (UP) 🚀", "🔴 PUT (DOWN) 🚀"])
    accuracy = random.randint(95, 99)
    
    signal_message = (
        "🔥 *PRINCE EHAAN VIP SIGNAL* 🔥\n"
        "━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📌 *Bot Name:* Trader Ehaan Signal\n"
        f"✨ *Brand:* Prince Ehaan\n"
        f"💱 *Asset:* `{pair}`\n"
        f"⏱ *Timeframe:* `{tf}`\n"
        f"📈 *Direction:* *{signal_type}*\n"
        f"🎯 *Accuracy:* `{accuracy}%`\n"
        "━━━━━━━━━━━━━━━━━━━━━━━\n"
        "⚡ **Entry Fast Now !** ⚡\n"
        "━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👑 *Trader:* Ꭾʀɪ፝֟፝ɴꮯᴇ Ꭼнꫝن 🩷🌸\n"
        f"💬 *Contact:* @PrinceEhaan\n"
        "⚠️ *Trade at your own risk. Use proper money management!*"
    )
    
    await callback.message.answer(signal_message, parse_mode="Markdown")
    await callback.answer(f"⚡ {tf} VIP Signal Generated!")

async def main():
    print("Trader Ehaan Signal Bot is starting...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
